from django.apps import AppConfig


class Restapi1Config(AppConfig):
    name = 'restapi1'
